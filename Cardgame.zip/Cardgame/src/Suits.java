public enum Suits {
    SPADER,
    HJÄRTER,
    RUTER,
    KLÖVER
}
