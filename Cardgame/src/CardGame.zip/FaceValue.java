public enum FaceValue {
    Ess,
    Två,
    Tre,
    Fyra,
    Fem,
    Sex,
    Sju,
    Åtta,
    Nio,
    Tio,
    Knekt,
    Dam,
    Kung
}
